﻿namespace TikTakToe
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Grid = new System.Windows.Forms.TableLayoutPanel();
            this.gridBtn1 = new System.Windows.Forms.Button();
            this.gridBtn2 = new System.Windows.Forms.Button();
            this.gridBtn3 = new System.Windows.Forms.Button();
            this.gridBtn5 = new System.Windows.Forms.Button();
            this.gridBtn6 = new System.Windows.Forms.Button();
            this.gridBtn7 = new System.Windows.Forms.Button();
            this.gridBtn4 = new System.Windows.Forms.Button();
            this.gridBtn8 = new System.Windows.Forms.Button();
            this.gridBtn9 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Game_Status = new System.Windows.Forms.Label();
            this.tie_Count_Label = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.message_Box = new System.Windows.Forms.RichTextBox();
            this.tie_Label = new System.Windows.Forms.Label();
            this.player2_Score_Box = new System.Windows.Forms.Label();
            this.player1_Score_Box = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.player2_Name_Box = new System.Windows.Forms.Label();
            this.playerInputName = new System.Windows.Forms.TextBox();
            this.player1_Name_Box = new System.Windows.Forms.Label();
            this.restartBtn = new System.Windows.Forms.Button();
            this.startBtn = new System.Windows.Forms.Button();
            this.Grid.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Grid
            // 
            this.Grid.ColumnCount = 3;
            this.Grid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.3F));
            this.Grid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.3F));
            this.Grid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.3F));
            this.Grid.Controls.Add(this.gridBtn1, 0, 0);
            this.Grid.Controls.Add(this.gridBtn2, 1, 0);
            this.Grid.Controls.Add(this.gridBtn3, 2, 0);
            this.Grid.Controls.Add(this.gridBtn5, 1, 1);
            this.Grid.Controls.Add(this.gridBtn6, 2, 1);
            this.Grid.Controls.Add(this.gridBtn7, 0, 2);
            this.Grid.Controls.Add(this.gridBtn4, 0, 1);
            this.Grid.Controls.Add(this.gridBtn8, 1, 2);
            this.Grid.Controls.Add(this.gridBtn9, 2, 2);
            this.Grid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Grid.Location = new System.Drawing.Point(0, 0);
            this.Grid.Name = "Grid";
            this.Grid.RowCount = 3;
            this.Grid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.3F));
            this.Grid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.3F));
            this.Grid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.3F));
            this.Grid.Size = new System.Drawing.Size(489, 334);
            this.Grid.TabIndex = 0;
            this.Grid.Paint += new System.Windows.Forms.PaintEventHandler(this.Grid_Paint);
            // 
            // gridBtn1
            // 
            this.gridBtn1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridBtn1.Location = new System.Drawing.Point(3, 3);
            this.gridBtn1.Name = "gridBtn1";
            this.gridBtn1.Size = new System.Drawing.Size(157, 105);
            this.gridBtn1.TabIndex = 0;
            this.gridBtn1.UseVisualStyleBackColor = true;
            this.gridBtn1.Click += new System.EventHandler(this.gridBtn_Click);
            // 
            // gridBtn2
            // 
            this.gridBtn2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridBtn2.Location = new System.Drawing.Point(166, 3);
            this.gridBtn2.Name = "gridBtn2";
            this.gridBtn2.Size = new System.Drawing.Size(157, 105);
            this.gridBtn2.TabIndex = 1;
            this.gridBtn2.UseVisualStyleBackColor = true;
            this.gridBtn2.Click += new System.EventHandler(this.gridBtn_Click);
            // 
            // gridBtn3
            // 
            this.gridBtn3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridBtn3.Location = new System.Drawing.Point(329, 3);
            this.gridBtn3.Name = "gridBtn3";
            this.gridBtn3.Size = new System.Drawing.Size(157, 105);
            this.gridBtn3.TabIndex = 2;
            this.gridBtn3.UseVisualStyleBackColor = true;
            this.gridBtn3.Click += new System.EventHandler(this.gridBtn_Click);
            // 
            // gridBtn5
            // 
            this.gridBtn5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridBtn5.Location = new System.Drawing.Point(166, 114);
            this.gridBtn5.Name = "gridBtn5";
            this.gridBtn5.Size = new System.Drawing.Size(157, 105);
            this.gridBtn5.TabIndex = 4;
            this.gridBtn5.UseVisualStyleBackColor = true;
            this.gridBtn5.Click += new System.EventHandler(this.gridBtn_Click);
            // 
            // gridBtn6
            // 
            this.gridBtn6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridBtn6.Location = new System.Drawing.Point(329, 114);
            this.gridBtn6.Name = "gridBtn6";
            this.gridBtn6.Size = new System.Drawing.Size(157, 105);
            this.gridBtn6.TabIndex = 5;
            this.gridBtn6.UseVisualStyleBackColor = true;
            this.gridBtn6.Click += new System.EventHandler(this.gridBtn_Click);
            // 
            // gridBtn7
            // 
            this.gridBtn7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridBtn7.Location = new System.Drawing.Point(3, 225);
            this.gridBtn7.Name = "gridBtn7";
            this.gridBtn7.Size = new System.Drawing.Size(157, 106);
            this.gridBtn7.TabIndex = 8;
            this.gridBtn7.UseVisualStyleBackColor = true;
            this.gridBtn7.Click += new System.EventHandler(this.gridBtn_Click);
            // 
            // gridBtn4
            // 
            this.gridBtn4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridBtn4.Location = new System.Drawing.Point(3, 114);
            this.gridBtn4.Name = "gridBtn4";
            this.gridBtn4.Size = new System.Drawing.Size(157, 105);
            this.gridBtn4.TabIndex = 3;
            this.gridBtn4.UseVisualStyleBackColor = true;
            this.gridBtn4.Click += new System.EventHandler(this.gridBtn_Click);
            // 
            // gridBtn8
            // 
            this.gridBtn8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridBtn8.Location = new System.Drawing.Point(166, 225);
            this.gridBtn8.Name = "gridBtn8";
            this.gridBtn8.Size = new System.Drawing.Size(157, 106);
            this.gridBtn8.TabIndex = 7;
            this.gridBtn8.UseVisualStyleBackColor = true;
            this.gridBtn8.Click += new System.EventHandler(this.gridBtn_Click);
            // 
            // gridBtn9
            // 
            this.gridBtn9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridBtn9.Location = new System.Drawing.Point(329, 225);
            this.gridBtn9.Name = "gridBtn9";
            this.gridBtn9.Size = new System.Drawing.Size(157, 106);
            this.gridBtn9.TabIndex = 6;
            this.gridBtn9.UseVisualStyleBackColor = true;
            this.gridBtn9.Click += new System.EventHandler(this.gridBtn_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(489, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(196, 334);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Game_Status);
            this.panel1.Controls.Add(this.tie_Count_Label);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.message_Box);
            this.panel1.Controls.Add(this.tie_Label);
            this.panel1.Controls.Add(this.player2_Score_Box);
            this.panel1.Controls.Add(this.player1_Score_Box);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.player2_Name_Box);
            this.panel1.Controls.Add(this.playerInputName);
            this.panel1.Controls.Add(this.player1_Name_Box);
            this.panel1.Controls.Add(this.restartBtn);
            this.panel1.Controls.Add(this.startBtn);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(190, 328);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // Game_Status
            // 
            this.Game_Status.AutoSize = true;
            this.Game_Status.Location = new System.Drawing.Point(21, 6);
            this.Game_Status.Name = "Game_Status";
            this.Game_Status.Size = new System.Drawing.Size(55, 13);
            this.Game_Status.TabIndex = 15;
            this.Game_Status.Text = "Waiting ...";
            // 
            // tie_Count_Label
            // 
            this.tie_Count_Label.AutoSize = true;
            this.tie_Count_Label.Location = new System.Drawing.Point(85, 104);
            this.tie_Count_Label.Name = "tie_Count_Label";
            this.tie_Count_Label.Size = new System.Drawing.Size(13, 13);
            this.tie_Count_Label.TabIndex = 14;
            this.tie_Count_Label.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(72, 72);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "    is   O";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(72, 46);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "    is   X";
            // 
            // message_Box
            // 
            this.message_Box.Location = new System.Drawing.Point(21, 222);
            this.message_Box.Name = "message_Box";
            this.message_Box.Size = new System.Drawing.Size(157, 28);
            this.message_Box.TabIndex = 11;
            this.message_Box.Text = "";
            this.message_Box.TextChanged += new System.EventHandler(this.message_Box_TextChanged);
            // 
            // tie_Label
            // 
            this.tie_Label.AutoSize = true;
            this.tie_Label.Location = new System.Drawing.Point(21, 104);
            this.tie_Label.Name = "tie_Label";
            this.tie_Label.Size = new System.Drawing.Size(58, 13);
            this.tie_Label.TabIndex = 10;
            this.tie_Label.Text = "Game Ties";
            //this.tie_Label.Click += new System.EventHandler(this.label6_Click);
            // 
            // player2_Score_Box
            // 
            this.player2_Score_Box.AutoSize = true;
            this.player2_Score_Box.Location = new System.Drawing.Point(130, 72);
            this.player2_Score_Box.Name = "player2_Score_Box";
            this.player2_Score_Box.Size = new System.Drawing.Size(13, 13);
            this.player2_Score_Box.TabIndex = 8;
            this.player2_Score_Box.Text = "0";
            // 
            // player1_Score_Box
            // 
            this.player1_Score_Box.AutoSize = true;
            this.player1_Score_Box.Location = new System.Drawing.Point(130, 46);
            this.player1_Score_Box.Name = "player1_Score_Box";
            this.player1_Score_Box.Size = new System.Drawing.Size(13, 13);
            this.player1_Score_Box.TabIndex = 7;
            this.player1_Score_Box.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(130, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Wins";
            // 
            // player2_Name_Box
            // 
            this.player2_Name_Box.AutoSize = true;
            this.player2_Name_Box.BackColor = System.Drawing.SystemColors.Control;
            this.player2_Name_Box.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.player2_Name_Box.Location = new System.Drawing.Point(24, 72);
            this.player2_Name_Box.Name = "player2_Name_Box";
            this.player2_Name_Box.Size = new System.Drawing.Size(2, 15);
            this.player2_Name_Box.TabIndex = 5;
            this.player2_Name_Box.Click += new System.EventHandler(this.player2_Name_Box_Click);
            // 
            // playerInputName
            // 
            this.playerInputName.Location = new System.Drawing.Point(21, 143);
            this.playerInputName.Name = "playerInputName";
            this.playerInputName.Size = new System.Drawing.Size(100, 20);
            this.playerInputName.TabIndex = 4;
            this.playerInputName.Text = "Enter your name";
            this.playerInputName.Click += new System.EventHandler(this.playerInputName_Click);
            this.playerInputName.TextChanged += new System.EventHandler(this.playerInputName_TextChanged);
            // 
            // player1_Name_Box
            // 
            this.player1_Name_Box.AutoSize = true;
            this.player1_Name_Box.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.player1_Name_Box.Location = new System.Drawing.Point(24, 46);
            this.player1_Name_Box.Name = "player1_Name_Box";
            this.player1_Name_Box.Size = new System.Drawing.Size(2, 15);
            this.player1_Name_Box.TabIndex = 2;
            // 
            // restartBtn
            // 
            this.restartBtn.Location = new System.Drawing.Point(8, 298);
            this.restartBtn.Name = "restartBtn";
            this.restartBtn.Size = new System.Drawing.Size(71, 21);
            this.restartBtn.TabIndex = 1;
            this.restartBtn.Text = "Reset";
            this.restartBtn.UseVisualStyleBackColor = true;
            this.restartBtn.Click += new System.EventHandler(this.restartBtn_Click);
            // 
            // startBtn
            // 
            this.startBtn.Location = new System.Drawing.Point(8, 265);
            this.startBtn.Name = "startBtn";
            this.startBtn.Size = new System.Drawing.Size(71, 21);
            this.startBtn.TabIndex = 0;
            this.startBtn.Text = "Restart";
            this.startBtn.UseVisualStyleBackColor = true;
            this.startBtn.Click += new System.EventHandler(this.restartButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(685, 334);
            this.Controls.Add(this.Grid);
            this.Controls.Add(this.tableLayoutPanel1);
            this.MinimumSize = new System.Drawing.Size(467, 291);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Grid.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel Grid;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button startBtn;
        private System.Windows.Forms.Button restartBtn;
        private System.Windows.Forms.Button gridBtn1;
        private System.Windows.Forms.Button gridBtn2;
        private System.Windows.Forms.Button gridBtn3;
        private System.Windows.Forms.Button gridBtn7;
        private System.Windows.Forms.Button gridBtn8;
        private System.Windows.Forms.Button gridBtn9;
        private System.Windows.Forms.Button gridBtn4;
        private System.Windows.Forms.Button gridBtn5;
        private System.Windows.Forms.Button gridBtn6;
        private System.Windows.Forms.Label player1_Name_Box;
        private System.Windows.Forms.TextBox playerInputName;
        private System.Windows.Forms.Label tie_Label;
        private System.Windows.Forms.Label player2_Score_Box;
        private System.Windows.Forms.Label player1_Score_Box;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label player2_Name_Box;
        private System.Windows.Forms.RichTextBox message_Box;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label tie_Count_Label;
        private System.Windows.Forms.Label Game_Status;
    }
}

